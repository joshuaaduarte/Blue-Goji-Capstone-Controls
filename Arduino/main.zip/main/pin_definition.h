#ifndef PIN_DEFINITION_H
#define PIN_DEFINITION_H

#define pwmA 9
#define in1A 7
#define in2A 8 
#define pwmB 11
#define in3B 12
#define in4B 10

#define startButton 2  // Yellow
#define emergencyButton 3 // Green
#define relay 4

#endif
